#include "dictionary.h"

/******************************************************************************
 *
 ******************************************************************************/
dictHist* hist = NULL;

/******************************************************************************
 *
 ******************************************************************************/
dictHist* getRefToHist(void)
{
	return hist;
}

/******************************************************************************
 *
 ******************************************************************************/
void pushToHist(dictHist **headRef, char *comp, char compSize)
{

	dictHist* newNode = (dictHist*)malloc(sizeof(dictHist));
	if(newNode == NULL)
	{
		printf("pushToHist:Could not allocate memory space\n");
		assert(false);
	}
	assert(HIST_COMP_MAX_SIZE > compSize);
	printf("new comp:%s\n", comp);

	memcpy(newNode->data, comp, compSize);
	newNode->size = compSize;

	newNode->next = *headRef;
	*headRef = newNode;
}

/******************************************************************************
 *
 ******************************************************************************/
void printArr(char* arr, int size)
{
	printf("arr:");
	for(int i = 0; i < size; i++)
	{
		printf("%d ", arr[i]);
	}
	printf("len:%d\n", size);
}
/******************************************************************************
 *
 ******************************************************************************/
#define MAX_LEN_COMP      HIST_COMP_MAX_SIZE
#define MAX_COMP_PER_LEN  HIST_COMP_MAX_SIZE

matrixHist matrix[MAX_LEN_COMP][MAX_COMP_PER_LEN + 1];

void initMatrix(void)
{
	for(int i = 0; i < sizeof(MAX_LEN_COMP); i++)
		for(int j = 0; j < sizeof(MAX_COMP_PER_LEN); j++)
			matrix[i][j].next = false;
}

void MatrixPushToSortedHist(char *comp, int compLen)
{
	assert(MAX_LEN_COMP > compLen - 1);

	printArr(comp, compLen);
	for(int i = 0; i < sizeof(MAX_COMP_PER_LEN); i++)
	{
		if(!matrix[compLen - 1][i].next)
		{
			matrix[compLen - 1][i].next = true;
			//memcpy(matrix[compLen - 1][i + 1].data, comp, compLen);
			for(int k = 0; k < compLen; k++)
				matrix[compLen - 1][i + 1].data[k] = comp[k];

			break;
		}
	}
}

/******************************************************************************
 *
 ******************************************************************************/
bool MatrixSearchInSortedHist(char *comp, int compLen)
{
	bool founded = false;

	assert(MAX_LEN_COMP > compLen - 1);

	for (int i = 0; i < sizeof(MAX_COMP_PER_LEN); i++)
	{
		if (!matrix[compLen - 1][i].next)
		{
			return false;
		}
		else
		{
			for (int j = 0; j < compLen; j++)
			{
				if (matrix[compLen - 1][i + 1].data[j] != comp[j])
				{
					break;
				}
				else
					return true;
			}
		}
	}

	return false;
}

/******************************************************************************
 *
 ******************************************************************************/
int MatrixGetDictFromString(char *ptrToStr, int size)
{
	int  hSize = 0;
	int  hSizeIncrement = 0;
	int  dictSize = 0;

	bool histDict = false;

	initMatrix();
	while(hSize < size)
	{
		if(!MatrixSearchInSortedHist(ptrToStr, (hSizeIncrement + 1)))
		{
			//printf("Pass to dict ");
			MatrixPushToSortedHist(ptrToStr, (hSizeIncrement + 1));
			dictSize++;
			if(!histDict)
				ptrToStr++;
			else
			{
				ptrToStr += hSizeIncrement + 1;
				hSizeIncrement = 0;
				histDict = false;
			}
		}
		else
		{
			histDict = true;
			hSizeIncrement++;
		}

		hSize++;
		//printf(".");
	}
	//printHistArray(getRefToHist());
	return dictSize;
}

/******************************************************************************
 *
 ******************************************************************************/
void test_MatrixGetDictFromString(void)
{
	//char ptrStrT[] = {"abcabdabb"};
	/************** Dictionary {abcabdabb} ****************
	 * a
	 * b
	 * c
	 * abd
	 * abb
	 *****************************************************/
	char ptrStrT[] = {90, 30, 10,30, 40, 10,20, 30,50};

	int dictSize;

	printf("\nTest MatrixGetDictFromString()\n");
	printArr(ptrStrT, sizeof(ptrStrT));
	dictSize = MatrixGetDictFromString(ptrStrT, sizeof(ptrStrT));
	printf("Dict size:%d\n", dictSize);
}
/******************************************************************************
 *
 ******************************************************************************/
void pushToSortedHist(dictHist **headRef, char *comp, int compSize)
{

	dictHist* newNode = (dictHist*)malloc(sizeof(dictHist));
	if(newNode == NULL)
	{
		printf("pushToHist:Could not allocate memory space\n");
		assert(false);
	}
	assert(HIST_COMP_MAX_SIZE > compSize);

	//printArr(comp, compSize);

	memcpy(newNode->data, comp, compSize);
	newNode->size = compSize;

	if (*headRef == NULL || (*headRef)->size >= newNode->size)
	{
		newNode->next = *headRef;
		*headRef = newNode;
	}
	else  // Locate the node before the point of insertion
	{
		dictHist* current = *headRef;

		while (current->next != NULL && current->next->size < newNode->size)
		{
			current = current->next;
		}
		newNode->next = current->next;
		current->next = newNode;
	}
}

/******************************************************************************
 *
 ******************************************************************************/
bool searchInSortedHist(dictHist *current, char *comp, int compSize)
{
	int goodSize;
	bool founded;
	bool foundSize = false;

	if(current == NULL)
		return false;
	else
		while(current != NULL)
		{
			if(foundSize && (goodSize < current->size))
				return false;

			if(current->size == compSize)
			{
				goodSize = compSize;
				foundSize = true;
				for(int i = 0; i < compSize; i++)
				{
					if(current->data[i] != comp[i])
					{
						founded = false;
						break;
					}
					else
						founded = true;
				}

				if(founded)
					return true;
			}

			current = current->next;
		}

	return false;
}
/******************************************************************************
 *
 ******************************************************************************/
void SortedInsert(dictHist** headRef, dictHist* newNode)
{
    // Special case for the head end
	if (*headRef == NULL || (*headRef)->size >= newNode->size)
	{
		newNode->next = *headRef;
		*headRef = newNode;
	}
	else  // Locate the node before the point of insertion
	{
		dictHist* current = *headRef;

		while (current->next != NULL && current->next->size < newNode->size)
		{
			current = current->next;
		}
		newNode->next = current->next;
		current->next = newNode;
	}
}

/******************************************************************************
 *
 ******************************************************************************/
// Given a list, change it to be in sorted order (using SortedInsert()).
void InsertSort(dictHist** headRef)
{
	dictHist* result = NULL;
    // build the answer here
	dictHist* current = *headRef; // iterate over the original list
	dictHist* next;
	while (current != NULL)
	{
		next = current->next;
        // tricky - note the next pointer before we change it
		SortedInsert(&result, current);
		current = next;
	}
	*headRef = result;
}

/******************************************************************************
 *
 ******************************************************************************/
void DeleteHistList(dictHist** headRef) {
	dictHist* current = *headRef; // deref headRef to get the real head
	dictHist* next;
	// note the next pointer
	// delete the node
	// advance to the next node
	// Again, deref headRef to affect the real head back
	// in the caller.
	while (current != NULL)
	{
		next = current->next;
		free(current);
		current = next;
	}
	*headRef = NULL;
}

/******************************************************************************
 * Print as a String
 ******************************************************************************/
void printHist(dictHist* hist)
{
	dictHist *current = hist;

	while(current != NULL)
	{
		printf("comp:%s len:%d\n", current->data, current->size);
	    current = current->next;
	}
}

/******************************************************************************
 * Print as an Array
 ******************************************************************************/
void printHistArray(dictHist* hist)
{
	dictHist *current = hist;

	while(current != NULL)
	{
		printArr(current->data, current->size);
	    current = current->next;
	}
}

/******************************************************************************
 *
 ******************************************************************************/
int getDictFromString(char *ptrToStr, int size)
{
	int  hSize = 0;
	int  hSizeIncrement = 0;
	int  dictSize = 0;

	bool histDict = false;

	while(hSize < size)
	{
		if(!searchInSortedHist(hist, ptrToStr, (hSizeIncrement + 1)))
		{
			//printf("Pass to dict ");
			pushToSortedHist(&hist, ptrToStr, (hSizeIncrement + 1));
			dictSize++;
			if(!histDict)
				ptrToStr++;
			else
			{
				ptrToStr += hSizeIncrement + 1;
				hSizeIncrement = 0;
				histDict = false;
			}
		}
		else
		{
			histDict = true;
			hSizeIncrement++;
		}

		hSize++;
		//printf(".");
	}
	//printHistArray(getRefToHist());
	DeleteHistList(&hist);
	return dictSize;
}

/******************************************************************************
 ** test getDictFromString
 ******************************************************************************/
void test_getDictFromString(void)
{
	//char ptrStrT[] = {"abcabdabb"};
	/************** Dictionary {abcabdabb} ****************
	 * a
	 * b
	 * c
	 * abd
	 * abb
	 *****************************************************/
	char ptrStrT[] = {10, 20, 10,30, 40, 10,20, 30,50, 30,50, 30,50,10};

	int dictSize;

	printf("\nTest getDictFromString()\n");
	printArr(ptrStrT, sizeof(ptrStrT));
	dictSize = getDictFromString(ptrStrT, sizeof(ptrStrT));
	printf("Dict size:%d\n", dictSize);
}

/******************************************************************************
 ** test function
 ******************************************************************************/
void testHist(void)
{
	char a[] = {"ab"};
	char b[] = {"c"};
	char c[] = {"ttt"};


	printf("\nTest push History\n");
 	pushToHist(&hist, a, sizeof(a));
	pushToHist(&hist, b, sizeof(b));
	pushToHist(&hist, c, sizeof(c));
	printHist(getRefToHist());

	printf("\nTest Sorted List from List\n");
	InsertSort(&hist);
	printHist(hist);

	printf("\nTest push to sorted History\n");
	dictHist* Hptr = NULL;
	char x[] = {"b"};
	char y[] = {"yyy"};

	pushToSortedHist(&Hptr, a, sizeof(a));
	pushToSortedHist(&Hptr, b, sizeof(b));
	pushToSortedHist(&Hptr, c, sizeof(c));
	pushToSortedHist(&Hptr, x, sizeof(x));
	pushToSortedHist(&Hptr, y, sizeof(y));
	printHist(Hptr);

	printf("\nTest search for string in sorted history list\n");
	bool founded = false;
	char d[] = {"ttt"};
	char e[] = {"tta"};
	char f[] = {"b"};
	char g[] = {"c"};
	char h[] = {"ba"};
	char i[] = {"bacs"};
	char j[] = {"yyy"};

	printf("search for:%s\n", b);
	founded = searchInSortedHist(Hptr, b, sizeof(b));
	printf("founded:%d\n", founded);
	printf("search for:%s\n", d);
	founded = searchInSortedHist(Hptr, d, sizeof(d));
	printf("founded:%d\n", founded);
	printf("search for:%s\n", e);
	founded = searchInSortedHist(Hptr, e, sizeof(e));
	printf("founded:%d\n", founded);
	printf("search for:%s\n", f);
	founded = searchInSortedHist(Hptr, f, sizeof(f));
	printf("founded:%d\n", founded);
	printf("search for:%s\n", g);
	founded = searchInSortedHist(Hptr, g, sizeof(g));
	printf("founded:%d\n", founded);
	printf("search for:%s\n", h);
	founded = searchInSortedHist(Hptr, h, sizeof(h));
	printf("founded:%d\n", founded);
	printf("search for:%s\n", i);
	founded = searchInSortedHist(Hptr, i, sizeof(i));
	printf("founded:%d\n", founded);
	printf("search for:%s\n", j);
	founded = searchInSortedHist(Hptr, j, sizeof(j));
	printf("founded:%d\n", founded);
}
