#ifndef MY_TYPES_H
#define MY_TYPES_H

//#define IMG_DATA_MAX_SIZE   33554432  // assume that image have max uncompressed 25bit size
#define IMG_DATA_MAX_SIZE   524288    // assume that image have max uncompressed 19bit size
#define FILE_NAME_MAX_SIZE  256       // assume that image name have max 8bit size

//#define HIST_COMP_MAX_SIZE  IMG_DATA_MAX_SIZE
//#define HIST_COMP_MAX_SIZE  (IMG_DATA_MAX_SIZE / 2) // assume that dictionary components have half size from image length
//#define HIST_COMP_MAX_SIZE  (IMG_DATA_MAX_SIZE / 4) // assume that dictionary components have 1/4 size from image length
//#define HIST_COMP_MAX_SIZE  (IMG_DATA_MAX_SIZE / 100) // assume that dictionary components have 1/100 size from image length
#define HIST_COMP_MAX_SIZE  (IMG_DATA_MAX_SIZE / 1000) // assume that dictionary components have 1/1000 size from image length  10-27 sec
//#define HIST_COMP_MAX_SIZE  (IMG_DATA_MAX_SIZE / 1500) // assume that dictionary components have 1/1000 size from image length  9.5-32 sec

typedef struct imgStruct_t
{
	char  imgData[IMG_DATA_MAX_SIZE];
	char  fileName[FILE_NAME_MAX_SIZE];
	int   imgNum;
	int   imageSize;
	int   width;
	int   height;
	struct imgStruct_t *next;
}imgStruct;

typedef struct dictHist_t
{
	char  data[HIST_COMP_MAX_SIZE];
	int   size;
	struct dictHist_t *next;
}dictHist;


typedef struct matrixHist_t
{
	char data[HIST_COMP_MAX_SIZE];
	bool next;
}matrixHist;

#endif // MY_TYPES_H
