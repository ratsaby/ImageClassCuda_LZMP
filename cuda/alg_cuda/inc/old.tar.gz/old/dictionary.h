#ifndef _DICTIONARY_H
#define _DICTIONARY_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>

#include "my_types.h"

void testHist(void);
void test_getDictFromString(void);
void test_MatrixGetDictFromString(void);
int MatrixGetDictFromString(char *ptrToStr, int size);
int getDictFromString(char *ptrToStr, int size);

#endif // _DICTIONARY
